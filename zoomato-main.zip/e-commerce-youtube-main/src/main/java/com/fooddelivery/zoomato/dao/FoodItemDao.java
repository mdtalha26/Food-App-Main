package com.fooddelivery.zoomato.dao;

import com.fooddelivery.zoomato.entity.FoodItem;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FoodItemDao extends CrudRepository<FoodItem, Integer> {
    public List<FoodItem> findAll(Pageable pageable);

    public List<FoodItem> findByFoodItemNameContainingIgnoreCaseOrFoodItemDescriptionContainingIgnoreCase(
            String key1, String key2, Pageable pageable
    );
}
