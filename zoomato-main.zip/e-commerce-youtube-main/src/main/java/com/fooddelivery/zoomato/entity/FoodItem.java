package com.fooddelivery.zoomato.entity;

import javax.persistence.*;
import java.util.Set;

@Entity
public class FoodItem {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer foodItemId;
    private String foodItemName;
    @Column(length = 2000)
    private String foodItemDescription;
    private Double foodItemDiscountedPrice;
    private Double foodItemActualPrice;
    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(name = "foodItem_images",
            joinColumns = {
                    @JoinColumn(name = "foodItem_id")
            },
            inverseJoinColumns = {
                    @JoinColumn(name = "image_id")
            }
    )
    private Set<ImageModel> foodItemImages;

    public FoodItem(Integer foodItemId, String foodItemName, String foodItemDescription, Double foodItemDiscountedPrice, Double foodItemActualPrice, Set<ImageModel> foodItemImages) {
        this.foodItemId = foodItemId;
        this.foodItemName = foodItemName;
        this.foodItemDescription = foodItemDescription;
        this.foodItemDiscountedPrice = foodItemDiscountedPrice;
        this.foodItemActualPrice = foodItemActualPrice;
        this.foodItemImages = foodItemImages;
    }

    public Integer getFoodItemId() {
        return foodItemId;
    }

    public void setFoodItemId(Integer foodItemId) {
        this.foodItemId = foodItemId;
    }

    public String getFoodItemName() {
        return foodItemName;
    }

    public void setFoodItemName(String foodItemName) {
        this.foodItemName = foodItemName;
    }

    public String getFoodItemDescription() {
        return foodItemDescription;
    }

    public void setFoodItemDescription(String foodItemDescription) {
        this.foodItemDescription = foodItemDescription;
    }

    public Double getFoodItemDiscountedPrice() {
        return foodItemDiscountedPrice;
    }

    public void setFoodItemDiscountedPrice(Double foodItemDiscountedPrice) {
        this.foodItemDiscountedPrice = foodItemDiscountedPrice;
    }

    public Double getFoodItemActualPrice() {
        return foodItemActualPrice;
    }

    public void setFoodItemActualPrice(Double foodItemActualPrice) {
        this.foodItemActualPrice = foodItemActualPrice;
    }

    public Set<ImageModel> getFoodItemImages() {
        return foodItemImages;
    }

    public void setFoodItemImages(Set<ImageModel> foodItemImages) {
        this.foodItemImages = foodItemImages;
    }
}
