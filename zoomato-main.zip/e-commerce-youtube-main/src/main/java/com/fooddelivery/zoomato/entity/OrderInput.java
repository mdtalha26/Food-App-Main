package com.fooddelivery.zoomato.entity;

import java.util.List;

public class OrderInput {

    private String fullName;
    private String fullAddress;
    private String contactNumber;
    private String alternateContactNumber;
    private String transactionId;
    private List<OrderFoodItemQuantity> orderFoodItemQuantityList;

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getFullAddress() {
        return fullAddress;
    }

    public void setFullAddress(String fullAddress) {
        this.fullAddress = fullAddress;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getAlternateContactNumber() {
        return alternateContactNumber;
    }

    public void setAlternateContactNumber(String alternateContactNumber) {
        this.alternateContactNumber = alternateContactNumber;
    }

    public List<OrderFoodItemQuantity> getOrderFoodItemQuantityList() {
        return orderFoodItemQuantityList;
    }

    public void setOrderFoodItemQuantityList(List<OrderFoodItemQuantity> orderFoodItemQuantityList) {
        this.orderFoodItemQuantityList = orderFoodItemQuantityList;
    }
}
