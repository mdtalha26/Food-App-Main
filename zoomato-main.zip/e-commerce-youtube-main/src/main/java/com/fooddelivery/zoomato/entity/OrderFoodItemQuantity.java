package com.fooddelivery.zoomato.entity;

public class OrderFoodItemQuantity {

    private Integer foodItemId;
    private Integer quantity;

    public Integer getFoodItemId() {
        return foodItemId;
    }

    public void setFoodItemId(Integer foodItemId) {
        this.foodItemId = foodItemId;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }
}
