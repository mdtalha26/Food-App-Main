package com.fooddelivery.zoomato.service;

import com.fooddelivery.zoomato.configuration.JwtRequestFilter;
import com.fooddelivery.zoomato.dao.CartDao;
import com.fooddelivery.zoomato.dao.FoodItemDao;
import com.fooddelivery.zoomato.dao.UserDao;
import com.fooddelivery.zoomato.entity.Cart;
import com.fooddelivery.zoomato.entity.FoodItem;
import com.fooddelivery.zoomato.entity.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FoodItemService {

    @Autowired
    private FoodItemDao foodItemDao;

    @Autowired
    private UserDao userDao;

    @Autowired
    private CartDao cartDao;

    public FoodItem addNewFoodItem(FoodItem foodItem) {
        return foodItemDao.save(foodItem);
    }

    public List<FoodItem> getAllFoodItems(int pageNumber, String searchKey) {
        Pageable pageable = PageRequest.of(pageNumber,12);

        if(searchKey.equals("")) {
            return (List<FoodItem>) foodItemDao.findAll(pageable);
        } else {
            return (List<FoodItem>) foodItemDao.findByFoodItemNameContainingIgnoreCaseOrFoodItemDescriptionContainingIgnoreCase(
                    searchKey, searchKey, pageable
            );
        }

    }

    public FoodItem getFoodItemDetailsById(Integer foodItemId) {
        return foodItemDao.findById(foodItemId).get();
    }

    public void deleteFoodItemDetails(Integer foodItemId) {
        foodItemDao.deleteById(foodItemId);
    }

    public List<FoodItem> getFoodItemDetails(boolean isSingleProductCheckout, Integer foodItemId) {
        if(isSingleProductCheckout && foodItemId != 0) {
            // we are going to buy a single product

            List<FoodItem> list = new ArrayList<>();
            FoodItem foodItem = foodItemDao.findById(foodItemId).get();
            list.add(foodItem);
            return list;
        } else {
            // we are going to checkout entire cart
            String username = JwtRequestFilter.CURRENT_USER;
            User user = userDao.findById(username).get();
            List<Cart> carts = cartDao.findByUser(user);

            return carts.stream().map(x -> x.getFoodItem()).collect(Collectors.toList());
        }
    }
}
